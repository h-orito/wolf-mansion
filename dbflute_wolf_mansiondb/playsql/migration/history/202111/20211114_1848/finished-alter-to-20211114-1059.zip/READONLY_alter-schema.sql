alter table FOOTSTEP modify column FOOTSTEP_ROOM_NUMBERS VARCHAR(1000) COMMENT '足音のした部屋 : カンマ区切り';

alter table MESSAGE modify column MESSAGE_CONTENT TEXT NOT NULL COMMENT 'メッセージ内容';