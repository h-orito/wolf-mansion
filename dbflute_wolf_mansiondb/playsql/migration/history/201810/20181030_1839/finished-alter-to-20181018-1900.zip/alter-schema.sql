alter table MESSAGE_RESTRICTION add column MESSAGE_MAX_LENGTH INT UNSIGNED NOT NULL COMMENT '最大文字数' after MESSAGE_MAX_NUM;
-- 表情種別
CREATE TABLE FACE_TYPE
(
	FACE_TYPE_CODE VARCHAR(20) NOT NULL COMMENT '表情種別コード',
	FACE_TYPE_NAME VARCHAR(20) NOT NULL COMMENT '表情種別名',
	DISP_ORDER INT UNSIGNED NOT NULL COMMENT '並び順',
	PRIMARY KEY (FACE_TYPE_CODE)
) COMMENT = '表情種別';

-- 表情種別のデータ登録
begin;
insert into FACE_TYPE values ('NORMAL', '通常', 1);
insert into FACE_TYPE values ('WEREWOLF', '囁き', 2);
insert into FACE_TYPE values ('GRAVE', '墓下', 3);
insert into FACE_TYPE values ('MONOLOGUE', '独り言', 4);
insert into FACE_TYPE values ('MASON', '共鳴', 5);
insert into FACE_TYPE values ('SECRET', '秘話', 6);
commit;

-- キャラクター画像
CREATE TABLE CHARA_IMAGE
(
	CHARA_ID INT UNSIGNED NOT NULL COMMENT 'キャラクターID',
	FACE_TYPE_CODE VARCHAR(20) NOT NULL COMMENT '表情種別コード',
	CHARA_IMG_URL VARCHAR(100) NOT NULL COMMENT 'キャラクター画像URL',
	PRIMARY KEY (CHARA_ID, FACE_TYPE_CODE)
) COMMENT = 'キャラクター画像';

ALTER TABLE CHARA_IMAGE
	ADD CONSTRAINT FK_CHARA_IMAGE_CHARA FOREIGN KEY (CHARA_ID)
	REFERENCES CHARA (CHARA_ID)
	ON UPDATE RESTRICT
	ON DELETE RESTRICT
;

ALTER TABLE CHARA_IMAGE
	ADD CONSTRAINT FK_CHARA_IMAGE_FACE_TYPE FOREIGN KEY (FACE_TYPE_CODE)
	REFERENCES FACE_TYPE (FACE_TYPE_CODE)
	ON UPDATE RESTRICT
	ON DELETE RESTRICT
;

-- キャラクター画像のデータ登録（ひとまず通常だけ）
begin;
insert into CHARA_IMAGE (chara_id, FACE_TYPE_code, chara_img_url)
select chara_id, 'NORMAL', chara_img_url from chara;
commit;

-- メッセージ
alter table MESSAGE add column 	FACE_TYPE_CODE VARCHAR(20) COMMENT '表情種別コード' after IS_CONVERT_DISABLE;

ALTER TABLE MESSAGE
	ADD CONSTRAINT FK_MESSAGE_FACE_TYPE FOREIGN KEY (FACE_TYPE_CODE)
	REFERENCES FACE_TYPE (FACE_TYPE_CODE)
	ON UPDATE RESTRICT
	ON DELETE RESTRICT
;

-- メッセージの表情種別登録（ひとまず全部通常に）
begin;
update MESSAGE set FACE_TYPE_CODE = 'NORMAL' 
where message_type_code in ('NORMAL_SAY', 'MONOLOGUE_SAY', 'GRAVE_SAY', 'WEREWOLF_SAY', 'MASON_SAY', 'SPECTATE_SAY', 'SECRET_SAY');
commit;

-- キャラクターから画像URL削除
alter table CHARA drop column chara_img_url;

-- キャラクターからダミーフラグを削除
alter table CHARA drop column is_dummy;

-- キャラクターに1日目デフォ発言を追加
alter table CHARA add column DEFAULT_FIRSTDAY_MESSAGE VARCHAR(200) COMMENT 'デフォルト1日目発言' after default_join_message;
begin;
update CHARA set DEFAULT_FIRSTDAY_MESSAGE = 'ふぁーあ……ねむいな……寝てていい？' where chara_id = 1;
update CHARA set DEFAULT_FIRSTDAY_MESSAGE = 'ちょっとオヤツ買い足してくるねー。' where chara_id = 60;
update CHARA set DEFAULT_FIRSTDAY_MESSAGE = '攻撃されて鎧が壊れてしまった。次襲われたら、もうおしまいじゃ' where chara_id = 142;
update CHARA set DEFAULT_FIRSTDAY_MESSAGE = 'え？　つまりこれって……どうしよう、みんなに伝えなきゃ……！' where chara_id = 311;


-- 村設定
alter table VILLAGE_SETTINGS add column DUMMY_CHARA_ID INT UNSIGNED NOT NULL COMMENT 'ダミーキャラID' after village_id;

-- 村設定のダミーキャラID修正
begin;
update VILLAGE_SETTINGS set dummy_chara_id = 1 where character_group_id = 1;
update VILLAGE_SETTINGS set dummy_chara_id = 59 where character_group_id = 2;
update VILLAGE_SETTINGS set dummy_chara_id = 60 where character_group_id = 3;
update VILLAGE_SETTINGS set dummy_chara_id = 142 where character_group_id = 4;
update VILLAGE_SETTINGS set dummy_chara_id = 311 where character_group_id = 5;
commit;


