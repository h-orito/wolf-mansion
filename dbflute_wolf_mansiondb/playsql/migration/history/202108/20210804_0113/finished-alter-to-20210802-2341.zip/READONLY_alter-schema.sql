insert into SKILL values ('WALLPUNCHER', '壁殴り代行', '壁', 'VILLAGER', 20);

insert into ABILITY_TYPE values ('WALLPUNCH','壁殴り');