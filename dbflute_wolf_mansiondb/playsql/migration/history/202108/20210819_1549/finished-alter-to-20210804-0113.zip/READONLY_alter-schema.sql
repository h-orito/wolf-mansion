insert into SKILL values ('HISHAWOLF','飛狼','飛','WEREWOLF',104);
insert into SKILL values ('KAKUWOLF','角狼','角','WEREWOLF',105);