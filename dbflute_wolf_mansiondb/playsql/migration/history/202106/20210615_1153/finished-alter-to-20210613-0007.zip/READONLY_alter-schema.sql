alter table CHARA_GROUP add column IS_AVAILABLE_CHANGE_NAME BOOLEAN NOT NULL COMMENT '名称変更可能か' after description_url;

update CHARA_GROUP set IS_AVAILABLE_CHANGE_NAME = true;