insert into SKILL values ('LONEWOLF', '一匹狼', '匹', 'CRIMINAL', 33);

insert into ABILITY_TYPE values ('LONEATTACK', '単独襲撃');