begin;
insert into MESSAGE_TYPE values ('PRIVATE_INVESTIGATE', '足音調査結果');
commit;