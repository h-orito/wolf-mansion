begin;
update SKILL set disp_order = 11 where skill_code = 'CMADMAN';
update SKILL set disp_order = 12 where skill_code = 'EVILMEDIUM';
update SKILL set disp_order = 13 where skill_code = 'FANATIC';
update SKILL set disp_order = 14 where skill_code = 'FOX';
update SKILL set disp_order = 15 where skill_code = 'LEFTOVER';
update SKILL set disp_order = 16 where skill_code = 'VILLAGERS';
update SKILL set disp_order = 17 where skill_code = 'WEREWOLFS';
update SKILL set disp_order = 18 where skill_code = 'NOVILLAGERS';
update SKILL set disp_order = 19 where skill_code = 'FOOTSTEPS';
update SKILL set disp_order = 20 where skill_code = 'FRIENDS';

insert into SKILL values ('DETECTIVE', '探偵', 'VILLAGER', 10);
commit;