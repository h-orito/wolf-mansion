insert into SKILL values ('LOVERS', 'おまかせ（恋人陣営）', 'お', 'VILLAGER', 28);

update SKILL set disp_order = 28 where skill_code = 'LOVERS';
update SKILL set disp_order = 29 where skill_code = 'NOVILLAGERS';
update SKILL set disp_order = 30 where skill_code = 'FOOTSTEPS';
update SKILL set disp_order = 31 where skill_code = 'FRIENDS';