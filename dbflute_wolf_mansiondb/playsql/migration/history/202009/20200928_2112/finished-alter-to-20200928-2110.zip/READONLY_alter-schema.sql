insert into SKILL values ('OWL', '梟', '梟', 'CRIMINAL', 27);

update SKILL set disp_order = 27 where skill_code = 'OWL';
update SKILL set disp_order = 28 where skill_code = 'LEFTOVER';
update SKILL set disp_order = 29 where skill_code = 'VILLAGERS';
update SKILL set disp_order = 30 where skill_code = 'WEREWOLFS';
update SKILL set disp_order = 31 where skill_code = 'LOVERS';
update SKILL set disp_order = 32 where skill_code = 'NOVILLAGERS';
update SKILL set disp_order = 33 where skill_code = 'FOOTSTEPS';
update SKILL set disp_order = 33 where skill_code = 'FRIENDS';