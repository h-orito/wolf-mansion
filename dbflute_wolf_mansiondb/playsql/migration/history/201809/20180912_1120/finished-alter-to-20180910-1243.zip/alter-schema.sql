alter table CHARA_GROUP add column DESCRIPTION_URL TEXT COMMENT 'キャラチップURL : キャラチップの利用規約や配布サイトのURL' after designer_id;
update CHARA_GROUP set description_url = 'https://www.irasutoya.com/' where chara_group_id = 1;
update CHARA_GROUP set description_url = 'http://electricbuster.jeez.jp/jnro/chipset/index2.html' where chara_group_id = 2;
update CHARA_GROUP set description_url = 'http://jsfun525.gamedb.info/wiki/?cmd=read&page=%BA%D0%BB%FE%BE%B6%B0%C6%C6%E2%A5%DA%A1%BC%A5%B8&word=%BA%D0%BB%FE%B5%AD' where chara_group_id = 3;
commit;