insert into ABILITY_TYPE values ('TRAP', '罠設置');
insert into ABILITY_TYPE values ('BOMB', '爆弾設置');