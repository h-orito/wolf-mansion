insert into CAMP values ('LOVERS', '恋人陣営');

insert into SKILL values ('LOVER', '恋人', '恋', 'LOVERS', 20);
insert into SKILL values ('COHABITER', '同棲者', '棲', 'LOVERS', 21);

update SKILL set disp_order = 1 where skill_code = 'VILLAGER';
update SKILL set disp_order = 2 where skill_code = 'SEER';
update SKILL set disp_order = 3 where skill_code = 'WISE';
update SKILL set disp_order = 4 where skill_code = 'ASTROLOGER';
update SKILL set disp_order = 5 where skill_code = 'MEDIUM';
update SKILL set disp_order = 6 where skill_code = 'GURU';
update SKILL set disp_order = 7 where skill_code = 'CORONER';
update SKILL set disp_order = 8 where skill_code = 'HUNTER';
update SKILL set disp_order = 9 where skill_code = 'MASON';
update SKILL set disp_order = 10 where skill_code = 'DETECTIVE';
update SKILL set disp_order = 11 where skill_code = 'TRAPPER';
update SKILL set disp_order = 12 where skill_code = 'BAKERY';
update SKILL set disp_order = 13 where skill_code = 'WEREWOLF';
update SKILL set disp_order = 14 where skill_code = 'CURSEWOLF';
update SKILL set disp_order = 15 where skill_code = 'WISEWOLF';
update SKILL set disp_order = 16 where skill_code = 'MADMAN';
update SKILL set disp_order = 17 where skill_code = 'CMADMAN';
update SKILL set disp_order = 18 where skill_code = 'EVILMEDIUM';
update SKILL set disp_order = 19 where skill_code = 'FANATIC';
update SKILL set disp_order = 20 where skill_code = 'LOVER';
update SKILL set disp_order = 21 where skill_code = 'COHABITER';
update SKILL set disp_order = 22 where skill_code = 'FOX';
update SKILL set disp_order = 23 where skill_code = 'IMMORAL';
update SKILL set disp_order = 24 where skill_code = 'BOMBER';
update SKILL set disp_order = 25 where skill_code = 'LEFTOVER';
update SKILL set disp_order = 26 where skill_code = 'VILLAGERS';
update SKILL set disp_order = 27 where skill_code = 'WEREWOLFS';
update SKILL set disp_order = 28 where skill_code = 'NOVILLAGERS';
update SKILL set disp_order = 29 where skill_code = 'FOOTSTEPS';
update SKILL set disp_order = 30 where skill_code = 'FRIENDS';

insert into MESSAGE_TYPE values ('LOVERS_SAY', '恋人発言');

insert into DEAD_REASON values ('SUICIDE', '後追');

insert into ABILITY_TYPE values ('COHABIT', '同棲');

CREATE TABLE VILLAGE_PLAYER_STATUS
(
	VILLAGE_PLAYER_STATUS_ID INT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '村参加者ステータスID',
	VILLAGE_PLAYER_ID INT UNSIGNED NOT NULL COMMENT '村参加者ID',
	TO_VILLAGE_PLAYER_ID INT UNSIGNED COMMENT '対象の村参加者ID',
	VILLAGE_PLAYER_STATUS_CODE VARCHAR(20) NOT NULL COMMENT '村参加者ステータス種別コード',
	REGISTER_DATETIME DATETIME NOT NULL COMMENT '登録日時',
	REGISTER_TRACE VARCHAR(64) NOT NULL COMMENT '登録トレース',
	UPDATE_DATETIME DATETIME NOT NULL COMMENT '更新日時',
	UPDATE_TRACE VARCHAR(64) NOT NULL COMMENT '更新トレース',
	PRIMARY KEY (VILLAGE_PLAYER_STATUS_ID)
) COMMENT = '村参加者ステータス';


CREATE TABLE VILLAGE_PLAYER_STATUS_TYPE
(
	VILLAGE_PLAYER_STATUS_TYPE_CODE VARCHAR(20) NOT NULL COMMENT '村参加者ステータス種別コード',
	VILLAGE_PLAYER_STATUS_TYPE_NAME VARCHAR(20) NOT NULL COMMENT '村参加者ステータス種別名',
	PRIMARY KEY (VILLAGE_PLAYER_STATUS_TYPE_CODE)
) COMMENT = '村参加者ステータス種別';

ALTER TABLE VILLAGE_PLAYER_STATUS
	ADD CONSTRAINT FK_VILLAGE_PLAYER_STATUS_VILLAGE_PLAYER FOREIGN KEY (VILLAGE_PLAYER_ID)
	REFERENCES VILLAGE_PLAYER (VILLAGE_PLAYER_ID)
	ON UPDATE RESTRICT
	ON DELETE RESTRICT
;


ALTER TABLE VILLAGE_PLAYER_STATUS
	ADD CONSTRAINT FK_VILLAGE_PLAYER_STATUS_TO_VILLAGE_PLAYER FOREIGN KEY (TO_VILLAGE_PLAYER_ID)
	REFERENCES VILLAGE_PLAYER (VILLAGE_PLAYER_ID)
	ON UPDATE RESTRICT
	ON DELETE RESTRICT
;


ALTER TABLE VILLAGE_PLAYER_STATUS
	ADD CONSTRAINT FK_VILLAGE_PLAYER_STATUS_VILLAGE_PLAYER_STATUS_TYPE FOREIGN KEY (VILLAGE_PLAYER_STATUS_CODE)
	REFERENCES VILLAGE_PLAYER_STATUS_TYPE (VILLAGE_PLAYER_STATUS_TYPE_CODE)
	ON UPDATE RESTRICT
	ON DELETE RESTRICT
;


insert into VILLAGE_PLAYER_STATUS_TYPE values ('FOLLOWING_SUICIDE', '後追い');

