alter table VILLAGE_PLAYER add column IS_SPECTATOR BOOLEAN NOT NULL COMMENT '見学者か' after is_dead;
update VILLAGE_PLAYER set is_spectator = '0';