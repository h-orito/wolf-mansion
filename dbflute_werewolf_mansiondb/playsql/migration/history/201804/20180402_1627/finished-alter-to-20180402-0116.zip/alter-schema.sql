alter table VILLAGE_SETTINGS add column IS_AVAILABLE_SPECTATE BOOLEAN NOT NULL COMMENT '見学可能か' after is_possible_skill_request;
update VILLAGE_SETTINGS set IS_AVAILABLE_SPECTATE = '0';