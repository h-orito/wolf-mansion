alter table VILLAGE_PLAYER add column CAMP_CODE VARCHAR(20) COMMENT '勝敗判定陣営コード' after last_access_datetime;
alter table VILLAGE_PLAYER add column IS_WIN BOOLEAN COMMENT '勝利したか' after CAMP_CODE;

update VILLAGE_PLAYER vp
	inner join SKILL s using (skill_code)
set vp.camp_code = s.camp_code;

update VILLAGE_PLAYER vp
	inner join SKILL s using (skill_code)
	inner join VILLAGE v using (village_id)
set is_win = true
where v.win_camp_code is not null
and s.camp_code = v.win_camp_code;

update VILLAGE_PLAYER vp
	inner join SKILL s using (skill_code)
	inner join VILLAGE v using (village_id)
set is_win = false
where v.win_camp_code is not null
and s.camp_code <> v.win_camp_code;
