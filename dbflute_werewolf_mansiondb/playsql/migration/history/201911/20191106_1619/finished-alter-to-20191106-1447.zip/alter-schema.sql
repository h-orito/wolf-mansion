insert into DEAD_REASON values ('TRAPPED', '罠死');
insert into DEAD_REASON values ('BOMBED', ' 爆死');