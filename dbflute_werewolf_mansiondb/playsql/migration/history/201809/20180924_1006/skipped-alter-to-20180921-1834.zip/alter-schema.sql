insert into SKILL values ('VILLAGERS', 'おまかせ（村人陣営）', 'VILLAGER', 15);
insert into SKILL values ('WEREWOLFS', 'おまかせ（狼陣営）', 'VILLAGER', 16);
insert into SKILL values ('NOVILLAGERS', 'おまかせ（人外）', 'VILLAGER', 17);
insert into SKILL values ('FOOTSTEPS', 'おまかせ（足音職）', 'VILLAGER', 18);
insert into SKILL values ('FRIENDS', 'おまかせ（役職窓あり）', 'VILLAGER', 19);
commit;