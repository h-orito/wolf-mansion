alter table MESSAGE add column IS_CONVERT_DISABLE BOOLEAN NOT NULL COMMENT '変換無効か' after message_datetime;
update MESSAGE set is_convert_disable = 0;