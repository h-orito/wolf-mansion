insert into SKILL values ('FANATIC', '狂信者', 'WEREWOLF', 12);
update SKILL set disp_order = 13 where skill_code = 'FOX';
update SKILL set disp_order = 14 where skill_code = 'LEFTOVER';
commit;