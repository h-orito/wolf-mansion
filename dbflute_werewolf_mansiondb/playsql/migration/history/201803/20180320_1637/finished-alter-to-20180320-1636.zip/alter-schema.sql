alter table VILLAGE add column CREATE_PLAYER_NAME VARCHAR(12) NOT NULL COMMENT '村作成プレイヤー名' after village_display_name;

update VILLAGE set create_player_name = 'master';