insert into SKILL values ('COURTSHIP', '求愛者', '求', 'LOVERS', 25);
insert into SKILL values ('STALKER', 'ストーカー', 'ス', 'LOVERS', 26);

update SKILL set disp_order = 25 where skill_code = 'COURTSHIP';
update SKILL set disp_order = 26 where skill_code = 'STALKER';
update SKILL set disp_order = 27 where skill_code = 'FOX';
update SKILL set disp_order = 28 where skill_code = 'IMMORAL';
update SKILL set disp_order = 29 where skill_code = 'BOMBER';
update SKILL set disp_order = 30 where skill_code = 'OWL';
update SKILL set disp_order = 31 where skill_code = 'FRUITSBASCKET';
update SKILL set disp_order = 32 where skill_code = 'LEFTOVER';
update SKILL set disp_order = 33 where skill_code = 'VILLAGERS';
update SKILL set disp_order = 34 where skill_code = 'WEREWOLFS';
update SKILL set disp_order = 35 where skill_code = 'LOVERS';
update SKILL set disp_order = 36 where skill_code = 'NOVILLAGERS';
update SKILL set disp_order = 37 where skill_code = 'FOOTSTEPS';
update SKILL set disp_order = 38 where skill_code = 'FRIENDS';
update SKILL set disp_order = 39 where skill_code = 'NOFRIENDS';

insert into ABILITY_TYPE values ('COURT', '求愛');
insert into ABILITY_TYPE values ('STALKING', 'ストーキング');

insert into MESSAGE_TYPE values ('PRIVATE_LOVER', '恋人メッセージ');