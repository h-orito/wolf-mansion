alter table MESSAGE add column CHARA_NAME VARCHAR(40) COMMENT 'キャラクター名' after face_type_code;
alter table MESSAGE add column TO_CHARA_NAME VARCHAR(40) COMMENT '秘話相手のキャラクター名' after chara_name;

update MESSAGE m
inner join VILLAGE_PLAYER vp using (village_player_id)
set m.chara_name = vp.chara_name
where m.village_player_id is not null;

update MESSAGE m
inner join VILLAGE_PLAYER vp on m.to_village_player_id = vp.village_player_id
set m.to_chara_name = vp.chara_name
where m.to_village_player_id is not null;

alter table VILLAGE_PLAYER add column CHARA_SHORT_NAME CHAR(1) NOT NULL COMMENT 'キャラクター略称' after chara_name;

update VILLAGE_PLAYER vp
inner join CHARA c using (chara_id)
set vp.chara_short_name = c.chara_short_name;

alter table MESSAGE add column CHARA_SHORT_NAME CHAR(1) COMMENT 'キャラクター略称' after chara_name;
alter table MESSAGE add column TO_CHARA_SHORT_NAME CHAR(1) COMMENT '秘話相手のキャラクター略称' after to_chara_name;

update MESSAGE m
inner join VILLAGE_PLAYER vp using (village_player_id)
set m.chara_short_name = vp.chara_short_name
where m.village_player_id is not null;

update MESSAGE m
inner join VILLAGE_PLAYER vp on m.to_village_player_id = vp.village_player_id
set m.to_chara_short_name = vp.chara_short_name
where m.to_village_player_id is not null;
