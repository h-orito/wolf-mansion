begin;
insert into ABILITY_TYPE values ('INVESTIGATE', '捜査');
commit;

alter table ABILITY add column TARGET_FOOTSTEP VARCHAR(100) COMMENT '行使対象の足音' after target_chara_id;
